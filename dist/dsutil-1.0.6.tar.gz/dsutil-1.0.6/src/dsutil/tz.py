from __future__ import annotations

from zoneinfo import ZoneInfo

TZ = ZoneInfo("America/New_York")
